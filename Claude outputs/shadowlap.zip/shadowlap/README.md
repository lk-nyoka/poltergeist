# Shadow Lap

**Test a new brake-by-wire controller against a real lap without letting it
touch the brakes. Built on QNX 8.0.**

Racing teams get very little track time, and every road-car maker that blends
motor braking with disc braking has the same problem: you can't let untested
control software brake a real car. Shadow Lap runs the new controller (v2)
beside the trusted one (v1). v2 sees every input and makes every decision, but
its decisions only go into a log. v1 stays in charge, and nothing v2 does
(crashing, hanging, hogging the CPU, attacking the brakes) can make v1 late.

The output is evidence: every moment the two disagreed, why, and how serious it was.

> Entry for the QNX Global Hackathon 2026, category **Automotive & Mobility**.
> Working name; rename freely.

## What it looks like

A full lap of Track A (a synthetic lap shaped like a fast, low-downforce
circuit). v2 is designed to harvest more energy. The report finds it:

- locks the rear wheels in the two hardest braking zones,
- overcharges a nearly full battery in three zones,
- keeps harvesting after the lap's energy limit is used up (a planted bug).

…while v1's timing is unchanged across all scenarios.

| Scenario | v1 deadline misses (of 9,016) | v1 p99 latency | v2 gaps |
|---|---|---|---|
| baseline (no shadow) | 0 | 154 µs | n/a |
| shadow | 0 | 157 µs | 0 |
| v2 crashes | 0 | 169 µs | 8,128 |
| v2 hangs 2 s | 0 | 196 µs | 100 |
| v2 SIGSTOPped 2 s | 1 | 214 µs | 100 |
| CPU flood on shadow side | 0 | 87 µs | 0 |
| v2 attacks the actuator | 3 | 161 µs | n/a |

**These numbers are from Linux (a cloud container), not QNX.** They show the
design works. The QNX runs are the next step and are what the submission
should quote. The single SIGSTOP miss is host jitter in that container. On
Linux the attack is *not* blocked, and the 3 misses are v2's command
overwriting v1's. That is the problem QNX permissions and security policy
exist to stop (see below).

## How it works

Five separate processes. Full plain-English walkthrough:
[docs/how-it-works.md](docs/how-it-works.md).

```
 lap replay ─► bbw_plant (the car, owns the clock and the actuator)
                 │  frame every 10 ms
        ┌────────┴─────────────┐
        ▼                      ▼  copy on a ring that never blocks
     bbw_v1 ──write()──►    bbw_v2 (shadow: watches only)
   /dev/bbw/actuator           │ proposals
   (only v1 can open)          ▼
                         bbw_comparer ─► compare.csv, summary.json ─► report.html
```

QNX features used:

- **Resource manager**: the brake actuator is `/dev/bbw/actuator`. v1's
  `write()` is a QNX message, and the plant thread handling it inherits v1's priority.
- **Process isolation + shared memory**: three separate regions, so v2 can
  only ever see its own.
- **Fixed priorities** (`SCHED_FIFO`) and **CPU pinning** (`ThreadCtl` runmask).
- **Permissions and security policies**: v2 is denied the actuator by the OS.
  See [docs/security-policy.md](docs/security-policy.md).

## Run it

Windows 11 step by step, including QNX in QEMU:
[docs/setup-windows11.md](docs/setup-windows11.md).

Quick start on Linux or WSL (no QNX needed):

```bash
make && make test
pip install numpy matplotlib
python3 tools/make_synthetic_lap.py          # writes data/lap_a.csv
sh scripts/run_demo.sh all out               # ~11 min: seven full laps
python3 tools/report.py out                  # writes out/report.html
```

**Watch it live:** in a second terminal run `python3 tools/live.py out`, then
open http://localhost:8000 while the demo runs. It follows each scenario as it
starts. On QNX, run the dashboard on your PC and point it at the copied
results, or see docs/setup-windows11.md.

On QNX (after `source ~/qnx800/qnxsdp-env.sh`):

```bash
make TARGET=qnx bundle                       # QEMU x86_64
make TARGET=qnx QNX_ARCH=aarch64le bundle    # Raspberry Pi
# copy build/qnx-*/bundle to the target, then on the target:
V2_USER=qnxuser PROD_CPU=0 SHADOW_CPU=1 sh run_demo.sh all out
```

Build and run details:

- **QNX version**: QNX SDP 8.0
- **Target**: QEMU x86_64 (`mkqnximage --type=qemu`); Raspberry Pi 4/5 should work with `QNX_ARCH=aarch64le`
- **Toolchain**: `qcc -Vgcc_ntox86_64` / `-Vgcc_ntoaarch64le`

Use a real lap instead of the synthetic one:

```bash
pip install fastf1
python3 tools/fetch_fastf1_lap.py --year 2024 --event Monza --session Q --out data/lap_real.csv
LAP=data/lap_real.csv sh scripts/run_demo.sh shadow out
```

## Repo map

| Path | What |
|---|---|
| `include/bbw.h` | messages, never-blocking ring buffer, shared regions |
| `include/control.h`, `src/control.c` | car limits, v1 and v2 strategies, disagreement rules |
| `src/plant.c` | simulated car, lap replay, deadline check |
| `src/actuator.c` | QNX resource manager (Linux: FIFO stand-in) |
| `src/v1.c`, `src/v2.c` | the two controllers; v2 has built-in fault injection |
| `src/comparer.c` | joins v1/v2 per frame, writes the evidence |
| `src/hog.c` | CPU burner for the flood test |
| `scripts/run_demo.sh` | the seven scenarios |
| `tools/` | synthetic lap, FastF1 import, HTML report |
| `tests/` | ring buffer stress test, strategy tests |

## Honest limits

- Battery, motor and forces are a small illustrative model (`include/control.h`).
  The lap only provides speed, throttle and a brake on/off flag.
- Shadow mode is open-loop: v2 sees a battery shaped by v1's choices.
- F1 cars use a standard control unit; this is a development and test-rig tool.
  The same approach applies to any EV or hybrid with blended braking.
- Not yet verified on QNX: the resource manager, CPU pinning, `on -u`, and the
  security-policy steps. Their code and steps follow QNX 8.0 documentation.

## License

MIT. See [LICENSE](LICENSE).
