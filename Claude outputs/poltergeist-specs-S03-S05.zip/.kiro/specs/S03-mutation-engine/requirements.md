# S03 — Mutation engine (requirements)

Agent: **mutant-maker** (run as the main agent for this spec). This is the only spec that writes under `apps/shop/src/mutants/`. The `builder`, `ghost-smith` and `judge` agents are denied those paths.

## Purpose

Seed the Haunted Shop with a library of hidden faults ("mutants"). Each mutant breaks exactly one contract rule (Appendix B, C1–C12) and must be catchable by at least one oracle mapped to that rule (§7.1a). The mutants are the known-answer key the benchmark scores every tool against. They are never seen by the ghost-writing agents, so the measurement stays fair.

## Definitions

- **Override**: a `MutantOverride` value (type from `@poltergeist/protocol`, written in S02): `{ id: string, seam: string, impl: Function, public: boolean }`. `impl(original, ...args)` wraps one seam; it may call `original` or replace it.
- **Public (demo) mutant**: `public === true`. Used by `{demo:true}` possessions in the live demo and **excluded from the benchmark**.
- **Non-public mutant**: `public === false`. The benchmark scores these only.
- **Rule**: one of C1–C12.

## Requirements (EARS)

### R1 — Count and spread
- THE mutant library SHALL export at least **40** overrides from `apps/shop/src/mutants/index.ts`.
- FOR each rule in C1–C12, THE library SHALL contain at least **3 non-public** overrides that break that rule.
- FOR rules C1, C4 and C8, THE library SHALL additionally contain exactly **one public** override (the demo mutant), giving those rules at least 4 overrides in total.
- THE library SHALL contain exactly **3 public** overrides in total (one each for C1, C4, C8) and no others.

### R2 — One rule each, and detectable
- EACH override SHALL break **exactly one** contract rule and SHALL leave all other rules intact on an otherwise-clean shop.
- FOR each override breaking rule Cₖ, at least one oracle mapped to Cₖ in §7.1a SHALL fire on a `{mutantIds:[id]}` session, AND no oracle SHALL fire on a `{clean:true}` session for the same steps.

### R3 — Opaque identity
- EACH override `id` SHALL be a random hex hash (≥ 8 bytes), never a descriptive name.
- EACH override SHALL live in its own file `apps/shop/src/mutants/m-<id>.ts`, re-exported by `index.ts`. The file name SHALL carry no hint of the rule or seam.

### R4 — Manifest and hash
- THE engine SHALL write `bench/mutant-manifest.json` validating against the `MutantManifest` schema (`packages/protocol`, S02): `{ version: 1, mutants: [{ id, rule: 'C1'..'C12', seam, public }] }`.
- THE manifest SHALL list every override exactly once, with the correct `rule`, `seam` and `public` flag.
- THE engine SHALL write the manifest's SHA-256 to `bench/manifest.sha256` and commit it **before** any scored benchmark run.
- ONLY `packages/scorer` SHALL read the manifest. The shop SHALL continue to select demo and random mutants from the `public` flag alone, never from the manifest.

### R5 — The clean shop stays clean
- WITH no mutants active (`{clean:true}`), THE shop SHALL still pass the full S02 contract suite unchanged.
- Adding the mutant library SHALL NOT change any shop source outside `apps/shop/src/mutants/`.

### R6 — mutant-check (rule level) is green
- THE `mutant-check` script (`pnpm --filter @poltergeist/scorer mutant-check`) SHALL, for every manifest entry, confirm that with `{mutantIds:[id]}` exactly the mapped rule's contract tests fail and the clean contract suite passes.
- mutant-maker SHALL run `mutant-check` once at the end of this spec and it SHALL report `checked N · ok K · wrong-rule 0 · undetected 0 · clean-suite PASS`.

## Out of scope
- No oracle code, driver, scorer maths or UI (those are S04+).
- No change to seams, sessions, routes or the contract suite.
