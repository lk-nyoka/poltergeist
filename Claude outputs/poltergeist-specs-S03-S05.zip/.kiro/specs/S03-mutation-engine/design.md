# S03 — Mutation engine (design)

Agent: **mutant-maker**. Steering: `.kiro/steering/mutants.md` (inclusion: manual — load it for this spec only). Reads the seam list from `apps/shop/src/seams/` to know which `seam('<module>/<export>')` names exist. Writes only under `apps/shop/src/mutants/` and `bench/`.

## How a mutant is written

Each mutant is one file `apps/shop/src/mutants/m-<id>.ts`:

```ts
import type { MutantOverride } from '@poltergeist/protocol';

export const mutant: MutantOverride = {
  id: '<random hex>',          // crypto.randomBytes(8).toString('hex')
  seam: '<module>/<export>',   // an existing seam name
  public: false,
  impl(original, ...args) {
    // break exactly one rule, then return a value of the original's shape
  },
};
```

`index.ts` collects them:

```ts
import type { MutantOverride } from '@poltergeist/protocol';
import { mutant as m0 } from './m-<id0>';
// …
export const overrides: MutantOverride[] = [m0, /* … */];
```

The S02 seam registry imports `overrides` statically and, at request time, applies the one whose `id` is in the session's active set.

## Procedure (do this per rule, C1 → C12)

1. From `apps/shop/src/seams/`, list the seams that implement the behaviour rule Cₖ governs (e.g. the checkout-intent seam for C1, the coupon seam for C4, a render seam for C8).
2. Write **≥ 3 non-public** overrides that each break Cₖ in a different, realistic way (the kinds of mistakes a developer actually ships), each on a seam that plausibly owns that behaviour.
3. Verify locally that with `{mutantIds:[id]}`:
   - the mapped rule's contract test(s) fail, and
   - the other 11 rules' contract tests still pass, and
   - the clean contract suite passes with the mutant off.
4. Give each a fresh random id and its own `m-<id>.ts` file; add it to `index.ts`.

Then add the **3 public demo mutants** — one each for C1, C4, C8 — chosen to be the most legible on screen for the live demo (a clear double charge, a coupon that drives the total below zero, a missing accessible name). Mark them `public: true`.

### Rule → example mutation shape (illustrative; write ≥3 distinct ones each)

| Rule | A way to break it (one of several) | Mapped oracle (§7.1a) |
| --- | --- | --- |
| C1 one charge per intent | mint a new idempotency key per click instead of per cart version | DoubleCharge |
| C2 refresh/back safety | drop the order row but keep the debit after a back step | StateLoss, DoubleCharge |
| C3 quantity 1–10 whole | accept non-integer or out-of-range quantity in the cart seam | QuantityBreach, TillLoss |
| C4 one coupon, discount ≤ subtotal | let a second coupon stack, or allow discount > subtotal | TillLoss |
| C5 server prices only | trust a `price` field from the client body | TillLoss |
| C6 totals ≥ 0, rounded once | round per-line (double rounding), or allow a negative total | TillLoss |
| C7 text never HTML | render a review/name field as HTML in a render seam | ScriptExecution |
| C8 accessible names / alt | drop a `aria-label`/`alt` in a render seam | A11yViolation |
| C9 dialog focus | weaken the focus trap or the Escape handler | FocusFailure |
| C10 text ≤100 cp, unchanged | trim/normalise/truncate stored text | TextCorruption, Crash |
| C11 own orders only | weaken the `.eq('session_id', …)` filter in a data seam | PrivacyLeak |
| C12 no 5xx on input | throw (500) on some out-of-contract input | Crash |

Each mutant must break **only** its row's rule. If breaking C11 also trips a crash, narrow the `impl` until only the C11 oracle fires.

## Manifest

After the overrides exist, generate `bench/mutant-manifest.json`:

```json
{ "version": 1, "mutants": [ { "id": "…", "rule": "C4", "seam": "pricing/applyCoupons", "public": false } ] }
```

- One entry per override, `rule` = the single rule it breaks, `seam` = its `seam`, `public` = its flag.
- Validate it against `MutantManifest` from `@poltergeist/protocol` before writing.
- Write the SHA-256 of the exact bytes to `bench/manifest.sha256` (e.g. `node -e "…createHash('sha256')…"`). Commit both.

The manifest and hash are a **fairness commitment**: they are frozen before the first scored run so no one can retune mutants to flatter a tool.

## Verification (end of spec)

1. `pnpm --filter @poltergeist/shop test` — the clean contract suite passes (R5).
2. Switch the `mutant-check` hook on in the Kiro hook panel (it was created disabled in S02), then run `pnpm --filter @poltergeist/scorer mutant-check`. Expect `checked N · ok N · wrong-rule 0 · undetected 0 · clean-suite PASS` (R6).
3. The `diary` hook is set to reply `skipped` for S03 (it must not read mutant files), so no diary entry is written for this spec. Record the counts manually in `docs/kiro-diary.md` if wanted, without naming any id or seam.

## Guardrails
- Never write anything outside `apps/shop/src/mutants/` and `bench/`.
- Never put a rule or seam hint in a file name or id.
- Never weaken the contract suite to make a mutant "pass".
- Keep each `impl` small and single-purpose.
