# S04 — Ghost core + scorer core (requirements)

Agent: **builder**. Builds the engine that ghosts and the scorer share: the `Driver` interface, an in-memory `FakeDriver`, the ten oracles (detectors), the recorder, replay + verification, the shrinker, and the scorer's kill maths and manifest reader. **No ghost personas and no UI** in this spec (ghosts are S06–S07, the Séance Room is S09–S10). The builder is denied `apps/shop/src/mutants/` and the mutant manifest.

Done when: **P1, P2 and P7 pass on the `FakeDriver`.**

## Requirements (EARS)

### R1 — Driver interface
- `packages/ghost-core/src/driver.ts` SHALL declare the `Driver` interface exactly as in brief §5.2 (`goto, click, type, press, back, reload, freshSession, request, query, focused, axe, onEvent, pointer`), with the `Locator`, `ElementInfo`, `PageEvent`, `PossessOptions` and `Unsubscribe` types it uses.
- THE interface SHALL be driver-agnostic: nothing in it SHALL assume Playwright, the DOM, or a real browser.

### R2 — FakeDriver
- `packages/ghost-core/src/fake/FakeDriver.ts` SHALL implement `Driver` fully in memory, modelling a tiny shop with the same contract (Appendix B) and its own switchable faults, so oracles, recorder, replay and scorer can be unit- and property-tested with no browser and no network.
- THE `FakeDriver` SHALL be deterministic given a haunting seed and a mutant set.

### R3 — Oracles (detectors)
- `packages/ghost-core/src/oracles/` SHALL implement all ten oracles in brief §7.1: `DoubleCharge, StateLoss, TillLoss, QuantityBreach, PrivacyLeak, ScriptExecution, TextCorruption, A11yViolation, FocusFailure, Crash`.
- EACH oracle SHALL decide independently of any mutant, from evidence only: money/privacy oracles read the shop's ledgers, orders and intents through `/api/oracle/*` (or the `FakeDriver`'s equivalent), never from values the page reports.
- THE `TillLoss` oracle SHALL compute its own reference total (Σ price × qty − min(discount, subtotal), rounded half-up once) from canonical prices and coupon values read from `GET /api/oracle/products`, using `orders.coupon_codes[0]` if present.
- Money/privacy oracle reads SHALL retry for up to 2 s before the oracle fires, to tolerate write delays.
- EACH oracle SHALL expose the fired/not-fired result plus the evidence needed for a certificate.

### R4 — Recorder
- THIS spec SHALL add the `Step` zod schema to `packages/protocol` (it is not created in S02), with a round-trip property test, before the recorder uses it.
- THE recorder SHALL record every driver call as a `Step`, with the haunting seed and the time gaps between steps.
- `freshSession` SHALL be recorded as `{kind:'freshSession'}` with **no** options; values read from the oracle API (`intent_id`, order ids) SHALL be recorded as placeholders (e.g. `{{intentId}}`) resolved at replay time.
- A finding's steps SHALL be the merged prefix since the last `freshSession` of the session it fired in (for a shrinker finding, only the shrunk counterexample's run).

### R5 — Replay and verification
- Replaying a step list SHALL open a fresh session with the same mutant set (`{cloneOf}`), supply recorded options from context, resolve placeholders, and honour recorded time gaps.
- A finding SHALL be **verified** if the same oracle fires in at least 1 of 3 replays on `{cloneOf}`; the reproduction rate (e.g. 3/3) SHALL be recorded.
- THE clean-replay check SHALL replay the same steps on a `{clean:true}` session; if the oracle fires there, the finding SHALL NOT count as a kill.

### R6 — Shrinker
- WHEN a Glitch-style property fails, THE shrinker SHALL reduce the failing input toward a simpler one that still fails, using a length-biased generator, and SHALL label its result "shrunk failing input" (never "smallest").
- WITH no time limit, THE shrinker's result SHALL still fail on replay and SHALL be no longer than the original; re-running with the same fast-check seed and path SHALL return the same input (**P2**).

### R7 — Scorer core (kill maths + manifest reader)
- `packages/scorer` SHALL read `bench/mutant-manifest.json` (validating the `MutantManifest` schema) and verify it against `bench/manifest.sha256`. The scorer's own tests SHALL use `packages/scorer/test/fixtures/manifest.fixture.json`, never the real manifest.
- A mutant breaking Cₖ SHALL be counted **killed** in a run only when (1) a verified finding appears whose oracle is mapped to Cₖ in §7.1a, **and** (2) the clean-replay check does not fire that oracle (brief §4 "Kill").
- Kill rate SHALL be kills ÷ mutants tested, averaged over haunting seeds.
- Every computed rate SHALL lie in [0, 1]; the killed set SHALL be a subset of the tested set; the seed mean SHALL equal the mean of the per-seed rates (**P7**).
- THE scorer SHALL NOT render any UI in this spec.

### R8 — Determinism (P1)
- FOR any recorded step list without timing-sensitive steps and any haunting seed, replaying twice through the `FakeDriver` on the same mutant set SHALL produce identical oracle results. Timing-sensitive steps SHALL report a reproduction rate instead.

## Out of scope
- Ghost personas / attack libraries (S06–S07), `PlaywrightDriver` and CLI (S05), `DomDriver` and hosted scheduler (S09), Séance Room UI (S10), certificates (S11).
