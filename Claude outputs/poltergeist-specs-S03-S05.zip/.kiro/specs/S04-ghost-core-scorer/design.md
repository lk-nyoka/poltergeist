# S04 — Ghost core + scorer core (design)

Agent: **builder**. Packages touched: `packages/protocol` (add the `Step` schema), `packages/ghost-core` (driver, FakeDriver, oracles, recorder, replay, shrinker), `packages/scorer` (kill maths, manifest reader). The `MutantManifest` schema already exists in `packages/protocol` (S02); the `Step` zod schema does **not** yet — add it in `packages/protocol` as the first task of this spec (brief §7.3), with a round-trip property test, before the recorder uses it. No browser, no network: everything in this spec is exercised through the `FakeDriver`.

## Package layout

```
packages/ghost-core/src/
  driver.ts            # Driver interface + Locator/ElementInfo/PageEvent/PossessOptions/Unsubscribe
  fake/FakeDriver.ts   # in-memory Driver + tiny contract-correct shop with switchable faults
  oracles/
    index.ts           # Oracle interface + registry
    doubleCharge.ts stateLoss.ts tillLoss.ts quantityBreach.ts privacyLeak.ts
    scriptExecution.ts textCorruption.ts a11yViolation.ts focusFailure.ts crash.ts
  record/recorder.ts   # driver calls -> Step[]
  replay/replay.ts     # Step[] -> fresh session replay + verification + clean-replay
  shrink/shrink.ts     # length-biased shrinker around fast-check
  index.ts
packages/scorer/src/
  manifest.ts          # read + hash-verify bench/mutant-manifest.json
  kill.ts              # kill decision (§7.1a map + clean-replay) and rate maths
  index.ts
packages/scorer/test/fixtures/manifest.fixture.json
```

## Driver interface

Copy §5.2 verbatim. Supporting types:
- `Locator`: an opaque selector token the driver resolves (role+name, test id, or CSS); never a live DOM node, so it serialises into a `Step`.
- `ElementInfo`: `{ role, name, box: {x,y,w,h}, focusable, disabled }`.
- `PageEvent`: `{ kind: 'pageerror'|'http5xx'|'beacon', ... }` for `onEvent`.
- `PossessOptions`: the `/api/possess` body union (`{clean:true} | {count} | {demo:true} | {cloneOf} | {mutantIds}`).

The interface makes no browser assumptions; `pointer` is a no-op outside the `DomDriver`.

## FakeDriver

An in-memory shop that obeys Appendix B and exposes the oracle surface (`/api/oracle/*` equivalents as method calls). It can switch on faults keyed to the same rules C1–C12 (its own, unrelated to the real mutants) so each oracle has something to detect in tests. Deterministic from `(haunting seed, mutant set)`. This is what P1/P2/P7 run against, so it must be the single source of truth for "what correct looks like" in tests.

## Oracles

One module per oracle, all implementing:

```ts
interface Oracle {
  id: OracleId;
  check(ctx: OracleContext): Promise<OracleResult>;  // { fired: boolean, evidence?: Evidence }
}
```

`OracleContext` gives read-only access to the oracle API (ledgers, orders, intents, products), the page query/axe/focused/events, and the submitted inputs. Behaviour per oracle is exactly brief §7.1; the key points a reviewer must not lose:

- **DoubleCharge**: > 1 customer debit sharing one `intent_id`.
- **StateLoss**: a customer debit for an `intent_id` with no `orders` row 2 s after a refresh/back.
- **TillLoss**: till goes down, or an order total < 0, or a total ≠ the oracle's **own** reference (Σ price×qty − min(discount, subtotal), rounded half-up once, from `/api/oracle/products` and `orders.coupon_codes[0]`). Never trust the page's number.
- **QuantityBreach**: an accepted line with a non-whole quantity or quantity outside 1–10.
- **PrivacyLeak**: `order_reads` shows the observed session read `stranger-order-fixed`.
- **ScriptExecution**: a unique beacon token from an injected payload calls `window.__poltergeistBeacon(token)`.
- **TextCorruption**: a contract-valid name/address/review comes back with `textContent` ≠ submitted.
- **A11yViolation**: axe-core reports any of the fixed rule set (`button-name, image-alt, svg-img-alt, input-image-alt, label, select-name, link-name, aria-command-name, aria-input-field-name`).
- **FocusFailure**: with a dialog open — tab escapes to background, or no reachable close + Escape doesn't close, or focus doesn't return to the opener after close.
- **Crash**: a page error, an error boundary render, or an HTTP 5xx on any input.

All reads retry ≤ 2 s before firing. Each returns evidence rich enough for a future certificate (the numbers, the element, the token), but this spec renders nothing.

## Recorder → Step

First define the `Step` zod schema in `packages/protocol` to cover the driver verbs (`goto, click, type, press, back, reload, freshSession, request`) plus `gapMs` and placeholder fields; export it and add a round-trip property test. Then the recorder:
- appends one `Step` per driver call with `gapMs` since the previous step and the haunting seed;
- writes `freshSession` as `{kind:'freshSession'}` with **no** options;
- replaces oracle-API reads used as inputs with placeholders `{{intentId}}`, `{{orderId}}`;
- can cut a finding's steps = merged prefix since the last `freshSession` (shrinker finding = just the shrunk run).

## Replay + verification

`replay(steps, base)`:
1. `freshSession({cloneOf: base})` (or `{clean:true}` for the clean-replay check).
2. Resolve placeholders from this session's oracle reads.
3. Execute each step, waiting the recorded `gapMs`.
4. Run the finding's oracle; return fired/not + evidence.

`verify(finding)`: replay 3× on `{cloneOf}`; verified if fired ≥ 1/3; record reproduction rate. `cleanReplay(finding)`: replay once on `{clean:true}`; if it fires, the finding is not a kill.

Timing-sensitive steps (double-click races, reload timing) are flagged; for those, P1 compares reproduction **rates**, not exact booleans.

## Shrinker

Wrap `fast-check` with a length-biased arbitrary (prefer shorter strings / smaller numbers). Run with `fc.check` (never `fc.assert`). With no time limit it must return a counterexample that still fails and is ≤ the original length; same fast-check seed + path ⇒ same input (P2). Label output "shrunk failing input".

## Scorer core

`manifest.ts`: read `bench/mutant-manifest.json`, recompute SHA-256, compare to `bench/manifest.sha256`; refuse to score on mismatch. Tests import the fixture manifest only.

`kill.ts`:
- `isKill(finding, mutantRule)` = `finding.verified && mapped(finding.oracle, mutantRule) && !cleanReplayFires(finding)` where `mapped` is the frozen §7.1a table.
- `rate(kills, tested)` = `kills.size / tested.size`, with `kills ⊆ tested` asserted.
- `seedMean(perSeedRates)` = arithmetic mean; assert it equals the mean of inputs and lies in [0,1].

The §7.1a map lives as a frozen constant with a test pinning it to the brief.

## Tests (the done-criteria)

- **P1**: property — for any non-timing step list and seed, two FakeDriver replays on the same mutant set give identical oracle results.
- **P2**: property — shrinker result (no time limit) still fails, is ≤ original length, and is stable per seed+path.
- **P7**: property — generated kill/tested sets ⇒ every rate in [0,1], killed ⊆ tested, kill only via the §7.1a map + clean-replay, seed mean = mean of per-seed rates.
- Plus unit tests: each oracle fires on its matching FakeDriver fault and stays silent on a clean session (this is the oracle-level analogue the real `mutant-check` extends in S05).

Run `pnpm --filter @poltergeist/ghost-core test` and `pnpm --filter @poltergeist/scorer test`; the `pbt-on-save` hook runs these in fast mode (100 runs) on every save.

## Guardrails
- Builder must not read or write `apps/shop/src/mutants/` or the real manifest (only the fixture).
- Keep hosted-only concerns out (round-robin, 20 s budgets, `driver.request` Glitch mode, second-iframe verification) — those are S09.
